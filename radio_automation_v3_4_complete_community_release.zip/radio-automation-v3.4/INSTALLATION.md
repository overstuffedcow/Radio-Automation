# Installation and operation guide — v3.4

## 1. Requirements

- Linux desktop or server (Pop!_OS / Ubuntu are good starting points)
- Docker Engine and Docker Compose plugin (`docker compose version`)
- Internet access to download the Node and Liquidsoap images on first launch
- An Icecast server/mount with source credentials; disable any competing AutoDJ/source using the same mount
- A browser on the same trusted computer or network

Docker installation differs by distribution. Follow the official Docker Engine and Compose plugin installation instructions for your Linux distribution, then verify:

```bash
docker --version
docker compose version
```

## 2. Extract and configure

Extract the release ZIP, open a terminal in the extracted `radio-automation-v3.4/` folder, then:

```bash
cp .env.example .env
nano .env
```

Configure:

- `ICECAST_HOST`: hostname or IP address of your Icecast server (without `http://`)
- `ICECAST_PORT`: Icecast source port (usually `8000`)
- `ICECAST_MOUNT`: e.g. `stream.mp3` (without leading slash)
- `ICECAST_USER`: commonly `source`
- `ICECAST_PASSWORD`: Icecast source password
- `TZ`: timezone, e.g. `America/Chicago`
- `AUDIO_GID`: Linux audio group ID, only relevant if you keep local audio device passthrough

Do not commit your `.env` to GitHub or share it in a ZIP.

## 3. Create folders and set permissions

```bash
mkdir -p media/music media/ids data/schedules data/logs
chmod 755 liquidsoap media media/music media/ids data data/schedules data/logs
chmod 644 liquidsoap/radio.liq
```

On a desktop, file manager **Properties / Permissions** can also be used to make `radio.liq` readable and directories traversable. A replacement file can reset permissions; recheck after upgrades. Avoid `chmod -R 777`.

Optional station ID: place an MP3 named `station-id.mp3` in `media/ids/`. Without a playable station ID and without scheduled music, there may be no useful audio to broadcast.

## 4. Headless machines / no sound card

The supplied `docker-compose.yml` retains optional `/dev/snd` passthrough from the working Linux setup. **If `/dev/snd` does not exist**, edit the compose file and delete the following entries from the `liquidsoap` service:

```yaml
devices:
  - /dev/snd:/dev/snd
group_add:
  - "${AUDIO_GID:-29}"
```

The bundled Liquidsoap script does **not** enable ALSA output; Icecast streaming works without a sound card.

## 5. Start

```bash
docker compose up -d --build
docker compose ps
```

Open `http://localhost:8088`. The dashboard's **host** port is 8088; its internal web container port is 8080. Do not change the internal `http://web:8080` reference in `radio.liq` when changing the dashboard's host port.

On first launch, open Weekly Schedule, choose a day and hour, add audio files or a folder using the picker, save the slot and **Publish weekly schedule**. Folder uploads copy music into the application's `media/music` library; they do not grant Docker direct access to arbitrary desktop directories.

Set the station name/logo in the dashboard. Configure Icecast source credentials in `.env`. Start the stream from the dashboard and verify audio from the **actual Icecast listener URL**. A green indicator by itself does not prove audio is playing.

## 6. Operating and monitoring

```bash
docker compose ps
docker compose logs --tail=100 web
docker compose logs --tail=100 liquidsoap
```

The `data/logs/playback-history.csv` file is intended to record playback metadata for reporting. Verify the entries against real playback before treating it as authoritative compliance evidence.

The top-of-hour station ID is queued to play at the next track boundary, rather than interrupting the current song.

## 7. Validate Liquidsoap configuration

```bash
docker compose run --rm --entrypoint liquidsoap liquidsoap --check /radio.liq
```

If you see `File is not readable! Given path: /radio.liq`, check that `liquidsoap/radio.liq` is a **regular file** and is readable (`chmod 644 liquidsoap/radio.liq`), then check the Docker bind mount. The script uses `source.on_track(radio, callback)` (source first) for Liquidsoap 2.3.1.

## 8. Backups and upgrades

Before updating, back up the whole project, especially `.env`, `media/`, `data/`, and any local changes to `liquidsoap/radio.liq` or `docker-compose.yml`. The public ZIP contains example `data/` files and **must not be extracted over a live installation without protecting your existing data**.

For a code-only upgrade, copy `app/server.js`, `app/public/index.html`, and (if required) `liquidsoap/radio.liq` after comparing local changes, then:

```bash
docker compose up -d --build --force-recreate web liquidsoap
```

To preserve an active broadcast during a web-only update, recreate just `web` instead.

## 9. Troubleshooting

- **Dashboard unreachable:** check `docker compose ps`, web logs, and whether another service uses port 8088.
- **Permission denied:** check file and parent-directory permissions, plus Docker bind mounts. The file manager's Properties/Permissions dialog works on desktop Linux.
- **Icecast 403 / mount in use:** another source or server-side AutoDJ may already own the mount.
- **No audio:** confirm a scheduled song exists, verify the actual listener URL, and inspect Liquidsoap logs. The station ID alone is not a substitute for a populated music library.
- **Wrong playback / scheduling:** verify selected day/hour, folder ordering, save slot, and publish the weekly schedule. Track changes occur at boundaries.
- **Metadata blank:** confirm the source sends metadata and Icecast exposes status JSON; playback may still be audible.
- **No `/dev/snd`:** remove the optional sound-device entries as described above.

## 10. Security reminder

The dashboard has no authentication and controls Docker via a mounted Docker socket. Restrict it to trusted access. For a local-only dashboard, consider changing `"8088:8080"` to `"127.0.0.1:8088:8080"` in compose; that will prevent access from other computers on the LAN.
