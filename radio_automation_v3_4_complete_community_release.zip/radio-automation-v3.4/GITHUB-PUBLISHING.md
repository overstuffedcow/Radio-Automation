# Publishing this project on GitHub

1. Read `README.md` and `INSTALLATION.md`, then test a clean installation yourself.
2. Decide who owns the copyright and choose a license. No license has been added automatically. Without a license, others generally cannot freely redistribute or modify your original code.
3. Do **not** upload `.env`, real station credentials, copyrighted music, private logs, or personal branding you don't intend to license. The included `.gitignore` excludes common private/runtime files.
4. Create a new GitHub repository (for example `radio-automation`).
5. From the project folder, run:

```bash
git init
git add .
git status                 # inspect every staged file carefully
git commit -m "Initial community release v3.4"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

6. Add screenshots, support/contact details, license, and issue templates if desired.
7. Create a GitHub Release and attach the public ZIP. Encourage testers to file issues with redacted logs (no passwords or private URLs).

**Security:** This is suitable for trusted local-network testing, not as an unauthenticated internet-facing service. The Docker socket mount gives the web application powerful host control.
