# Radio Automation — Community Release v3.4

A Docker-based, browser-controlled internet radio automation project for Linux. Developed through iterative testing for KPOG and Praise Radio. **This is an independent community project, not affiliated with those stations or Icecast/Liquidsoap.**

## Features

- Weekly schedule: 7 days × 24 hours, with multiple folders per hour
- Add individual songs or folders **directly on the Weekly Schedule page** using your browser's file picker
- Random, alphabetical, or numerical folder playback order; random rotation fallback and three-hour repeat avoidance (subject to library size)
- Hourly station-ID queue (plays at a track boundary)
- Icecast MP3 streaming through Liquidsoap 2.3.1
- Now Playing and connection status, station name and logo, playback CSV history, logs
- Browser control of the Liquidsoap container

## Start here

Read **INSTALLATION.md** for full installation, first broadcast, permissions, upgrades, backups, and troubleshooting.

Quick start (Linux with Docker Engine and Docker Compose plugin installed):

```bash
cp .env.example .env
nano .env                    # set Icecast host and source password
mkdir -p media/music media/ids data/schedules data/logs
chmod 755 liquidsoap media media/music media/ids data data/schedules data/logs
chmod 644 liquidsoap/radio.liq
# Place a station ID at media/ids/station-id.mp3 (optional but recommended)
docker compose up -d --build
```

Dashboard: **http://localhost:8088**.

**Important:** The included compose file maps `/dev/snd` for optional local audio support. On headless systems without `/dev/snd`, remove the `devices:` and `group_add:` entries under `liquidsoap` before starting. See INSTALLATION.md.

## Security

**Do not expose port 8088 to the public internet.** This dashboard has **no login** and its web container mounts the Docker socket to manage containers. The Docker socket grants extremely powerful host-level privileges. Restrict access to your own trusted computer/network, and do not run this as a public web service without substantial security redesign. The `.env` editor exposes streaming credentials to dashboard users.

## What's in this release

This complete package combines the v3.2 base project, v3.4 web dashboard/server updates, and the corrected v3.3 Liquidsoap playback script. It is not a patch; it includes Docker files, sample settings, sample schedule, and source code. No music, personal credentials, or station logos are included.

## Testing and limitations

The original operator confirmed automatic song-to-song playback and v3.4 scheduling on their system. The assembled community ZIP has passed a Node.js syntax check and ZIP integrity check; it has **not** been independently integration-tested as a clean installation on multiple computers. Please test before relying on it for an unattended broadcast. There is no authentication, installer wizard, or automated test suite yet.

## Sharing on GitHub

See **GITHUB-PUBLISHING.md**. The project creator should choose and add a software license before inviting redistribution or contributions. Dependencies have their own licenses.
