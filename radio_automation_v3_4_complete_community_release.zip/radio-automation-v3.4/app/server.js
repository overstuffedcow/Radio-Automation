const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { promisify } = require("util");
const execFileAsync = promisify(execFile);

const app = express();
const PORT = Number(process.env.PORT || 8080);
const MEDIA_DIR = process.env.MEDIA_DIR || "/media";
const DATA_DIR = process.env.DATA_DIR || "/data";
const MUSIC_DIR = path.join(MEDIA_DIR, "music");
const IDS_DIR = path.join(MEDIA_DIR, "ids");
const SCHEDULE_DIR = path.join(DATA_DIR, "schedules");
const SCHEDULE_JSON = path.join(DATA_DIR, "weekly-schedule.json");
const SETTINGS_FILE = path.join(DATA_DIR, "settings.json");
const ROTATION_HISTORY = path.join(DATA_DIR, "rotation-history.json");
const NOW_PLAYING_FILE = path.join(DATA_DIR, "now-playing.json");
const SEQUENCE_FILE = path.join(DATA_DIR, "folder-sequences.json");
const LOGO_DIR = path.join(DATA_DIR, "branding");
const LOG_DIR = path.join(DATA_DIR, "logs");
const PLAYBACK_CSV = path.join(LOG_DIR, "playback-history.csv");
const LOG_FILE = path.join(LOG_DIR, "radio-automation.log");
const LOG_CURSOR_FILE = path.join(LOG_DIR, ".docker-log-cursor");
const CONFIG_FILE = process.env.LIQUIDSOAP_CONFIG || "/config/radio.liq";
const LIQUIDSOAP_CONTAINER = process.env.LIQUIDSOAP_CONTAINER || "radio-automation-liquidsoap";
let lastDockerLogSince = Math.max(0, Number.parseInt((() => { try { return fs.readFileSync(LOG_CURSOR_FILE, "utf8"); } catch { return ""; } })(), 10) || Math.floor(Date.now() / 1000) - 3);
const DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
const DAY_LABELS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const defaultSettings = {
  stationName: "My Radio Station",
  stationIdPath: "/media/ids/station-id.mp3",
  normalize: true,
  crossfadeSeconds: 4,
  repeatWeeklySchedule: true,
  rotationEnabled: true, rotationDirectory: "/media/music", rotationNoRepeatHours: 3, stationLogo: ""
};
for (const dir of [MEDIA_DIR, DATA_DIR, MUSIC_DIR, IDS_DIR, SCHEDULE_DIR, LOG_DIR, path.join(DATA_DIR, "config-backups"), LOGO_DIR]) fs.mkdirSync(dir, { recursive: true });
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

function jsonRead(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return fallback; }
}
function safeName(s) { return path.basename(String(s)).replace(/[^a-zA-Z0-9._ -]/g, "_").slice(0, 150); }
function listFiles(dir, prefix) {
  const out=[];
  function walk(current, relative, depth) {
    if(depth>8 || out.length>20000)return;
    for(const entry of fs.readdirSync(current,{withFileTypes:true})) {
      if(entry.name.startsWith(".") || entry.isSymbolicLink())continue;
      const rel=relative ? relative+"/"+entry.name : entry.name;
      if(entry.isDirectory())walk(path.join(current,entry.name),rel,depth+1);
      else if(entry.isFile() && AUDIO_EXT.has(path.extname(entry.name).toLowerCase()))out.push({name:rel,path:prefix+"/"+rel,bytes:fs.statSync(path.join(current,entry.name)).size});
    }
  }
  walk(dir,"",0);
  return out.sort((a,b)=>a.name.localeCompare(b.name));
}
function readSettings() { return { ...defaultSettings, ...jsonRead(SETTINGS_FILE, {}) }; }
function readSchedule() {
  const s = jsonRead(SCHEDULE_JSON, { version: 1, updatedAt: null, slots: {} });
  if (!s.slots) s.slots = {};
  if (!s.modes || typeof s.modes !== "object") s.modes = {};
  for (const d of DAYS) for (let h=0; h<24; h++) {
    const key = `${d}-${String(h).padStart(2,"0")}`;
    if (!Array.isArray(s.slots[key])) s.slots[key] = [];
    if (!["playlist", "random"].includes(s.modes[key])) s.modes[key] = s.slots[key].length ? "playlist" : "random";
  }
  if (!s.folders || typeof s.folders !== "object") s.folders = {};
  return s;
}
function validMediaPath(p) {
  if(typeof p!=="string" || !/^\/media\/(music|ids)\/[a-zA-Z0-9._ \/-]+$/.test(p))return false;
  const target=path.resolve(MEDIA_DIR,p.replace(/^\/media\//,""));
  const root=path.resolve(MEDIA_DIR);
  if(!target.startsWith(root+path.sep))return false;
  try {const real=fs.realpathSync(target);return real.startsWith(fs.realpathSync(root)+path.sep) && fs.statSync(real).isFile();}catch{return false;}
}
function saveSchedule(s) {
  const slots = {}, modes = {}, folders = {};
  for (const d of DAYS) for (let h=0; h<24; h++) {
    const key = `${d}-${String(h).padStart(2,"0")}`;
    const raw = Array.isArray(s.slots[key]) ? s.slots[key] : [];
    slots[key] = raw.filter(validMediaPath).slice(0, 250);
    modes[key] = s.modes && s.modes[key] === "random" ? "random" : (s.modes && s.modes[key] === "playlist" ? "playlist" : (slots[key].length ? "playlist" : "random"));
    folders[key] = (Array.isArray(s.folders?.[key]) ? s.folders[key] : []).slice(0, 20).map(x => ({path:String(x.path||""),order:["random","alphabetical","numerical"].includes(x.order)?x.order:"random"})).filter(x => {try{return Boolean(validRotationDirectory(x.path));}catch{return false;}});
    const m3u = path.join(SCHEDULE_DIR, `${key}.m3u`);
    fs.writeFileSync(m3u, "#EXTM3U\n" + (modes[key] === "playlist" ? slots[key].join("\n") : "") + (modes[key] === "playlist" && slots[key].length ? "\n" : ""), {mode: 0o644});
    try { fs.chmodSync(m3u, 0o644); } catch {}
  }
  const saved = { version: 3, updatedAt: new Date().toISOString(), slots, modes, folders };
  fs.writeFileSync(SCHEDULE_JSON, JSON.stringify(saved, null, 2));
  return saved;
}
// Ensure all 168 playlist files exist before Liquidsoap tries to load them.
saveSchedule(readSchedule());

function writeLog(level, message) {
  try {
    if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 5 * 1024 * 1024) {
      const previous = `${LOG_FILE}.1`;
      try { fs.unlinkSync(previous); } catch {}
      fs.renameSync(LOG_FILE, previous);
    }
  } catch (e) { console.error("Could not rotate persistent log:", e.message); }
  const line = `${new Date().toISOString()} [${level}] ${String(message).replace(/[\r\n]+/g, " ")}\n`;
  try { fs.appendFileSync(LOG_FILE, line); } catch (e) { console.error("Could not write persistent log:", e.message); }
  if (level === "ERROR") console.error(line.trim()); else console.log(line.trim());
}
async function docker(args, options = {}) {
  return execFileAsync("docker", args, { timeout: options.timeout || 12000, maxBuffer: options.maxBuffer || 2 * 1024 * 1024 });
}
async function getEngineRunning() {
  try {
    const { stdout } = await docker(["inspect", "-f", "{{.State.Running}}", LIQUIDSOAP_CONTAINER], { timeout: 5000 });
    return stdout.trim() === "true";
  } catch { return false; }
}
function csvCell(value) { const v=String(value??"").replace(/\r?\n/g," "); return '"'+v.replace(/"/g,'""')+'"'; }
function recordPlayed(meta) {
  const at=new Date().toISOString();
  const file=String(meta.filename||meta.file||meta.source||"");
  const title=String(meta.title||path.basename(file)||"Unknown");
  const artist=String(meta.artist||"");
  const album=String(meta.album||"");
  const row={at,filename:file,title,artist,album,metadata:meta};
  if (!fs.existsSync(PLAYBACK_CSV)) fs.writeFileSync(PLAYBACK_CSV,'"started_at_utc","filename","title","artist","album","metadata_json"\n');
  fs.appendFileSync(PLAYBACK_CSV,[at,file,title,artist,album,JSON.stringify(meta)].map(csvCell).join(",")+"\n");
  fs.writeFileSync(NOW_PLAYING_FILE,JSON.stringify(row,null,2));
}
function parseTrackMetadata(line) {
  const raw=line.split("KPOG_PLAY_START ")[1];
  if (!raw) return null;
  const meta={raw};
  for (const k of ["filename","file","source","title","artist","album"]) {
    const match=raw.match(new RegExp('(?:^|[,;{\\s])'+k+'\\s*[:=]\\s*([^,;}]+)', 'i'));
    if (match) meta[k]=match[1].trim().replace(/^['\"]|['\"]$/g,'');
    if (!meta[k]) { const pair=raw.match(new RegExp("[\\x27\\x22]"+k+"[\\x27\\x22]\\s*,\\s*[\\x27\\x22]([^\\x27\\x22]+)","i")); if(pair) meta[k]=pair[1]; }
  }
  return meta;
}
async function collectEngineLogs() {
  try {
    const since = String(lastDockerLogSince);
    const { stdout, stderr } = await docker(["logs", "--since", since, "--timestamps", LIQUIDSOAP_CONTAINER], { timeout: 7000, maxBuffer: 4 * 1024 * 1024 });
    const combined = [stdout, stderr].filter(Boolean).join("\n");
    if (combined.trim()) {
      const lines = combined.split(/\r?\n/).filter(Boolean);
      for (const line of lines) {
        const track=parseTrackMetadata(line);
        if (track) { try { recordPlayed(track); } catch(e) { writeLog("ERROR", "Playback CSV write: "+e.message); } }
        const isError = /\b(error|fatal|failed|failure|exception|cannot connect|connection refused|unable to open|decoder error)\b/i.test(line);
        const isWarning = /\b(warn|warning|retry|reconnect)\b/i.test(line);
        writeLog(isError ? "ERROR" : isWarning ? "WARN" : "ENGINE", line);
      }
    }
  } catch (e) {
    // A stopped container is expected while the operator has taken the stream off air.
    if (!/No such container|is not running|not found/i.test(e.message)) writeLog("WARN", `Could not collect Liquidsoap logs: ${e.message}`);
  } finally {
    lastDockerLogSince = Math.max(lastDockerLogSince + 1, Math.floor(Date.now() / 1000) - 1);
    try { fs.writeFileSync(LOG_CURSOR_FILE, String(lastDockerLogSince)); } catch (e) { writeLog("WARN", `Could not save Docker log cursor: ${e.message}`); }
  }
}
function readTail(file, count = 400) {
  try { return fs.readFileSync(file, "utf8").split(/\r?\n/).filter(Boolean).slice(-count).join("\n"); }
  catch { return "No log entries yet."; }
}


function parseEnvFile(content) {
  const out = {};
  for (const raw of String(content).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const idx = line.indexOf("=");
    if (idx < 1) continue;
    const key = line.slice(0, idx).trim();
    let value = line.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (/^[A-Z][A-Z0-9_]*$/.test(key)) out[key] = value;
  }
  return out;
}
function envFilePath() { return process.env.ENV_FILE || "/project/.env"; }
function envAllowedKeys() {
  return new Set(["ICECAST_HOST","ICECAST_PORT","ICECAST_MOUNT","ICECAST_USER","ICECAST_PASSWORD","AUDIO_GID","TZ"]);
}
function getEnvDocument() {
  const content = fs.readFileSync(envFilePath(), "utf8");
  const values = parseEnvFile(content);
  // The editor edits the .env file only; it never edits radio.liq.
  return { content, path: envFilePath(), values };
}
function icecastStatusUrl() {
  const env = parseEnvFile(fs.readFileSync(envFilePath(), "utf8"));
  const host = String(env.ICECAST_HOST || process.env.ICECAST_HOST || "").trim();
  if (!host) return null;
  const port = String(env.ICECAST_PORT || process.env.ICECAST_PORT || "8000").trim();
  const mount = String(env.ICECAST_MOUNT || process.env.ICECAST_MOUNT || "stream.mp3").trim().replace(/^\/+/, "");
  if (!/^[a-zA-Z0-9.-]+$/.test(host) || !/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535) return null;
  const proto = "http://";
  const cleanHost = host.replace(/^https?:\/\//i, "").replace(/\/+$/, "");
  const hostPort = cleanHost.includes(":") ? cleanHost : `${cleanHost}:${port}`;
  return `${proto}${hostPort}/status-json.xsl?mount=${encodeURIComponent("/" + mount)}`;
}
async function probeIcecast() {
  const url=icecastStatusUrl();
  if (!url) return {state:"error",connected:false,title:"",detail:"Icecast server not configured."};
  try {
    const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),3500);
    let response;
    try { response=await fetch(url,{signal:controller.signal,headers:{Accept:"application/json"}}); }
    finally { clearTimeout(timer); }
    if (!response.ok) {
      // A server may disable status-json.xsl while still accepting source connections.
      const root=new URL(url);root.pathname="/";root.search="";
      const ping=await fetch(root,{signal:controller.signal}).catch(()=>null);
      if (ping) return {state:"connected",connected:true,title:"",detail:"Icecast server reachable (status metadata unavailable).",mountActive:false};
      throw new Error("Icecast HTTP "+response.status);
    }
    const data=await response.json();
    let sources=data?.icestats?.source||[];
    if (!Array.isArray(sources)) sources=[sources];
    const mount="/"+String(parseEnvFile(fs.readFileSync(envFilePath(),"utf8")).ICECAST_MOUNT||process.env.ICECAST_MOUNT||"stream.mp3").replace(/^\/+/,"");
    const source=sources.find(x=>{try{return new URL(String(x.listenurl)).pathname===mount;}catch{return false;}});
    const title=source ? String(source.title||([source.artist,source.song].filter(Boolean).join(" — "))||"") : "";
    return {state:"connected",connected:true,title,detail:source?"Icecast reachable; broadcast mount active.":"Icecast reachable; broadcast mount currently inactive.",mountActive:Boolean(source),listeners:Number(source?.listeners||0)};
  } catch(e) {return {state:"error",connected:false,title:"",detail:e.name==="AbortError"?"Icecast connection timed out.":e.message};}
}


function currentSlotKey() {
  const date = new Date();
  // JS: Sunday=0; schedule: Monday=0
  const day = (date.getDay() + 6) % 7;
  return `${DAYS[day]}-${String(date.getHours()).padStart(2,"0")}`;
}
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, req.query.kind === "id" ? IDS_DIR : MUSIC_DIR),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${safeName(file.originalname) || "audio-file"}`)
});
const upload = multer({ storage, limits: { fileSize: 500 * 1024 * 1024 } });

app.get("/api/status", async (req,res) => {
  const schedule = readSchedule();
  const slot = currentSlotKey();
  const icecast = await probeIcecast();
  res.json({
    ok: true, station: readSettings().stationName,
    currentSlot: slot, currentSlotMode: schedule.modes[slot], currentSlotTracks: (schedule.slots[slot] || []).length,
    musicFiles: listFiles(MUSIC_DIR, "/media/music").length,
    stationIds: listFiles(IDS_DIR, "/media/ids").length,
    scheduleUpdatedAt: schedule.updatedAt,
    icecastConfigured: Boolean(process.env.ICECAST_HOST && process.env.ICECAST_PASSWORD),
    icecast,
    nowPlaying: jsonRead(NOW_PLAYING_FILE,null),
    stationLogo: readSettings().stationLogo,
    localAudioDevice: fs.existsSync("/dev/snd"),
    streamRunning: await getEngineRunning(),
    logFile: "/data/logs/radio-automation.log"
  });
});

// Rotation is selected only when Liquidsoap requests another track.
// History survives container restarts. Only regular audio files are considered.
const AUDIO_EXT = new Set([".mp3", ".ogg", ".opus", ".wav", ".flac", ".m4a", ".aac"]);
function validRotationDirectory(value) {
  const requested = String(value || "/media/music");
  const root = fs.realpathSync(MUSIC_DIR);
  const resolved = path.resolve(requested);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) throw new Error("Rotation folder must be inside /media/music.");
  return resolved;
}
function rotationFiles(folder) {
  const root = fs.realpathSync(MUSIC_DIR);
  let real;
  try { real = fs.realpathSync(folder); } catch { return []; }
  if (real !== root && !real.startsWith(root + path.sep)) return [];
  const out = [];
  function walk(dir, depth) {
    if (depth > 8 || out.length >= 20000) return;
    for (const entry of fs.readdirSync(dir, {withFileTypes:true})) {
      if (entry.name.startsWith(".")) continue;
      const full = path.join(dir,entry.name);
      if (entry.isDirectory()) walk(full,depth+1);
      else if (entry.isFile() && AUDIO_EXT.has(path.extname(entry.name).toLowerCase()) && fs.statSync(full).size > 0) out.push(full);
    }
  }
  walk(real,0);
  return out;
}
function rotationState() {
  const settings = readSettings();
  const folder = validRotationDirectory(settings.rotationDirectory);
  const files = rotationFiles(folder);
  const hours = settings.rotationNoRepeatHours;
  const history = jsonRead(ROTATION_HISTORY, {plays:[]});
  const now = Date.now();
  const plays = (Array.isArray(history.plays) ? history.plays : []).filter(x => x && typeof x.file === "string" && Number.isFinite(x.at) && now - x.at < 24*3600000);
  const blocked = new Set(plays.filter(x => now - x.at < hours*3600000).map(x => x.file));
  const eligible = files.filter(f => !blocked.has(f));
  return {settings, files, eligible, plays, folder, hours};
}
// Responds with the selected audio file itself; Liquidsoap can decode this URL.
function naturalSort(a,b) { return path.basename(a).localeCompare(path.basename(b),undefined,{numeric:true,sensitivity:"base"}); }
function nextFromFolder(folder, order, slot, noRepeatHours) {
  const files=rotationFiles(validRotationDirectory(folder));
  if (!files.length) return null;
  const history=jsonRead(ROTATION_HISTORY,{plays:[]}).plays||[];
  const cutoff=Date.now()-noRepeatHours*3600000;
  const eligible=files.filter(f=>!history.some(h=>h.file===f&&h.at>=cutoff));
  if (!eligible.length) return null;
  if (order==="random") return eligible[Math.floor(Math.random()*eligible.length)];
  const ordered=files.sort(naturalSort);
  const sequences=jsonRead(SEQUENCE_FILE,{});
  const id=slot+"|"+folder;
  const previous=Number(sequences[id]??-1);
  const next=Array.from({length:ordered.length},(_,i)=>ordered[(previous+1+i)%ordered.length]).find(f=>eligible.includes(f));
  if (!next) return null;
  sequences[id]=ordered.indexOf(next);
  fs.writeFileSync(SEQUENCE_FILE,JSON.stringify(sequences,null,2));
  return next;
}
function selectScheduledFile() {
  const slot=currentSlotKey(), schedule=readSchedule(), settings=readSettings();
  const folderConfigs=schedule.folders?.[slot]||[];
  if (schedule.modes[slot]==="playlist") {
    // Legacy hand-picked tracks take priority if configured.
    const tracks=(schedule.slots[slot]||[]).filter(validMediaPath);
    if (tracks.length) {
      const idxFile=path.join(DATA_DIR,"legacy-sequences.json"), indices=jsonRead(idxFile,{});
      const i=(Number(indices[slot]||0))%tracks.length;
      indices[slot]=i+1;fs.writeFileSync(idxFile,JSON.stringify(indices));
      return tracks[i].replace(/^\/media\//,MEDIA_DIR+"/");
    }
  }
  // Folder entries rotate as a group, each preserving its own ordering.
  const stateFile=path.join(DATA_DIR,"folder-roundrobin.json"), state=jsonRead(stateFile,{});
  const nextIndex=Number(state[slot]||0);
  for(let i=0;i<folderConfigs.length;i++) {
    const index=(nextIndex+i)%folderConfigs.length;
    const cfg=folderConfigs[index];
    const f=nextFromFolder(cfg.path,cfg.order,slot,settings.rotationNoRepeatHours);
    if(f) {state[slot]=(index+1)%folderConfigs.length;fs.writeFileSync(stateFile,JSON.stringify(state));return f;}
  }
  if(!settings.rotationEnabled) return null;
  return nextFromFolder(settings.rotationDirectory,"random",slot,settings.rotationNoRepeatHours);
}
app.get("/api/playout/next",(req,res)=>{
  try {
    const selected=selectScheduledFile();
    if(!selected) return res.status(503).send("No eligible scheduled or fallback music");
    const old=jsonRead(ROTATION_HISTORY,{plays:[]}).plays||[];
    fs.writeFileSync(ROTATION_HISTORY,JSON.stringify({plays:[...old.filter(p=>Date.now()-p.at<24*3600000),{file:selected,at:Date.now()}]},null,2));
    res.set("Cache-Control","no-store");res.sendFile(selected);
  } catch(e){writeLog("ERROR","Playout selection: "+e.message);res.status(500).send("Playout selection failed");}
});
app.get("/api/playback/csv",(req,res)=>{
  if(!fs.existsSync(PLAYBACK_CSV)) fs.writeFileSync(PLAYBACK_CSV,'"started_at_utc","filename","title","artist","album","metadata_json"\n');
  res.download(PLAYBACK_CSV,"playback-history.csv");
});
app.get("/api/folders",(req,res)=>{
  const root=fs.realpathSync(MUSIC_DIR), dirs=["/media/music"];
  function walk(dir,depth){if(depth>5)return;for(const ent of fs.readdirSync(dir,{withFileTypes:true})){if(ent.isDirectory()&&!ent.name.startsWith(".")){const full=path.join(dir,ent.name);dirs.push(full.replace(root,"/media/music"));walk(full,depth+1);}}}
  walk(root,0);res.json({folders:dirs});
});
const logoUpload=multer({storage:multer.diskStorage({destination:(req,file,cb)=>cb(null,LOGO_DIR),filename:(req,file,cb)=>cb(null,"station-logo"+({"image/png":".png","image/jpeg":".jpg","image/webp":".webp"}[file.mimetype]||".img"))}),limits:{fileSize:3*1024*1024},fileFilter:(req,file,cb)=>cb(null,["image/png","image/jpeg","image/webp"].includes(file.mimetype))});
app.post("/api/station/logo",logoUpload.single("logo"),(req,res)=>{
  if(!req.file)return res.status(400).json({error:"Choose PNG, JPG, or WebP under 3MB"});
  const settings=readSettings();settings.stationLogo="/api/station/logo?file="+encodeURIComponent(req.file.filename);
  fs.writeFileSync(SETTINGS_FILE,JSON.stringify(settings,null,2));res.json({ok:true,stationLogo:settings.stationLogo});
});
app.get("/api/station/logo",(req,res)=>{
  const name=path.basename(String(req.query.file||""));
  if(!/^station-logo\.(png|jpg|webp)$/.test(name))return res.sendStatus(404);
  res.sendFile(path.join(LOGO_DIR,name));
});
app.get("/api/rotation/next", (req,res) => {
  try {
    const r = rotationState();
    if (!r.settings.rotationEnabled) return res.status(503).send("Random rotation disabled");
    if (!r.files.length) return res.status(503).send("No audio files in rotation folder");
    if (!r.eligible.length) {
      writeLog("WARN", `Rotation exhausted: ${r.files.length} tracks, ${r.hours}-hour protection. No song repeated.`);
      return res.status(503).send("No eligible tracks: add music or reduce no-repeat window");
    }
    const selected = r.eligible[Math.floor(Math.random()*r.eligible.length)];
    // Record the selection before responding so simultaneous requests cannot repeat it.
    const plays = [...r.plays, {file:selected, at:Date.now()}];
    fs.writeFileSync(ROTATION_HISTORY, JSON.stringify({plays},null,2));
    writeLog("ROTATION", `Selected ${path.basename(selected)} (${r.eligible.length} eligible; ${r.hours}h no-repeat)`);
    res.set("Cache-Control", "no-store, no-cache, must-revalidate");
    res.type(path.extname(selected).toLowerCase() === ".mp3" ? "audio/mpeg" : "application/octet-stream");
    res.sendFile(selected);
  } catch (e) { writeLog("ERROR", `Rotation selection: ${e.message}`); res.status(500).send("Rotation error"); }
});
app.get("/api/rotation/status", (req,res) => {
  try { const r = rotationState(); res.json({enabled:r.settings.rotationEnabled,directory:r.folder,noRepeatHours:r.hours,tracks:r.files.length,eligible:r.eligible.length,historyEntries:r.plays.length,warning:r.files.length && !r.eligible.length ? "All tracks are inside the no-repeat window. Add songs or reduce the window." : null}); }
  catch(e) { res.status(400).json({error:e.message}); }
});

app.get("/api/settings", (req,res) => res.json(readSettings()));
app.put("/api/settings", (req,res) => {
  const old = readSettings(), b = req.body || {};
  let folder;
  try { folder = validRotationDirectory(b.rotationDirectory ?? old.rotationDirectory); } catch (e) { return res.status(400).json({error:e.message}); }
  const s = {
    ...old,
    stationName: String(b.stationName ?? old.stationName).slice(0,100),
    stationIdPath: String(b.stationIdPath || old.stationIdPath),
    crossfadeSeconds: Math.max(0,Math.min(12,Number(b.crossfadeSeconds ?? old.crossfadeSeconds))),
    normalize: Boolean(b.normalize),
    repeatWeeklySchedule: true,
    rotationEnabled: b.rotationEnabled === undefined ? old.rotationEnabled : Boolean(b.rotationEnabled),
    rotationDirectory: folder,
    rotationNoRepeatHours: Math.max(1, Math.min(24, Number(b.rotationNoRepeatHours ?? old.rotationNoRepeatHours) || 3))
  };
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(s,null,2));
  res.json(s);
});
app.get("/api/library", (req,res) => res.json({
  music: listFiles(MUSIC_DIR,"/media/music"), ids: listFiles(IDS_DIR,"/media/ids")
}));
app.post("/api/upload", upload.single("audio"), (req,res) => {
  if (!req.file) return res.status(400).json({error:"Choose a file first."});
  res.json({ok:true,file:req.file.filename,kind:req.query.kind === "id" ? "id" : "music"});
});
// Browser file and directory pickers upload files into the persistent music mount.
const scheduleUpload=multer({storage:multer.memoryStorage(),limits:{fileSize:500*1024*1024,files:1}});
app.post("/api/schedule/upload",scheduleUpload.single("audio"),(req,res)=>{
  try {
    if(!req.file)return res.status(400).json({error:"Choose an audio file."});
    const ext=path.extname(req.file.originalname).toLowerCase();
    if(!AUDIO_EXT.has(ext))return res.status(400).json({error:"Unsupported audio format."});
    const folderName=String(req.body.folder||"").trim();
    // Folder labels are plain names, never filesystem paths supplied by the browser.
    if(folderName && (folderName==="." || folderName===".." || folderName.length>100 || !/^[a-zA-Z0-9 _.-]+$/.test(folderName)))return res.status(400).json({error:"Invalid folder name."});
    const target=folderName?path.join(MUSIC_DIR,folderName):MUSIC_DIR;
    fs.mkdirSync(target,{recursive:true});
    const fileName=Date.now()+"-"+Math.random().toString(36).slice(2,8)+"-"+safeName(req.file.originalname);
    fs.writeFileSync(path.join(target,fileName),req.file.buffer,{flag:"wx"});
    const virtualFolder="/media/music"+(folderName?"/"+folderName:"");
    res.json({ok:true,path:virtualFolder+"/"+fileName,folder:virtualFolder,file:fileName});
  } catch(e){res.status(500).json({error:e.message});}
});
app.get("/api/schedule", (req,res) => res.json({days:DAY_LABELS, dayKeys:DAYS, schedule:readSchedule()}));
app.put("/api/schedule", (req,res) => {
  if (!req.body || !req.body.slots || typeof req.body.slots !== "object") return res.status(400).json({error:"slots object required"});
  const saved = saveSchedule({slots:req.body.slots,modes:req.body.modes || {},folders:req.body.folders||{}});
  res.json({ok:true,schedule:saved,message:"Weekly schedule saved. Hourly playlist files reload automatically."});
});
app.post("/api/schedule/copy-day", (req,res) => {
  const {sourceDay,targetDay} = req.body || {};
  if (!DAYS.includes(sourceDay) || !DAYS.includes(targetDay)) return res.status(400).json({error:"Choose valid days."});
  const s = readSchedule();
  for (let h=0; h<24; h++) {
    const a = `${sourceDay}-${String(h).padStart(2,"0")}`, b = `${targetDay}-${String(h).padStart(2,"0")}`;
    s.slots[b] = [...(s.slots[a] || [])];
    s.modes[b] = s.modes[a];
    s.folders[b] = (s.folders[a]||[]).map(x=>({...x}));
  }
  const saved = saveSchedule(s);
  res.json({ok:true,schedule:saved});
});
app.post("/api/schedule/clear", (req,res) => {
  const slots = {};
  for (const d of DAYS) for (let h=0; h<24; h++) slots[`${d}-${String(h).padStart(2,"0")}`] = [];
  const modes = Object.fromEntries(Object.keys(slots).map(k => [k, "random"]));
  res.json({ok:true,schedule:saveSchedule({slots,modes,folders:{}})});
});

app.post("/api/stream/:action", async (req, res) => {
  const action = req.params.action;
  if (!["start", "stop", "restart"].includes(action)) return res.status(400).json({ error: "Action must be start, stop, or restart." });
  const args = action === "start" ? ["start", LIQUIDSOAP_CONTAINER] : action === "stop" ? ["stop", "--timeout", "10", LIQUIDSOAP_CONTAINER] : ["restart", "--timeout", "10", LIQUIDSOAP_CONTAINER];
  try {
    const { stdout, stderr } = await docker(args, { timeout: 25000 });
    writeLog("CONTROL", `Operator requested stream ${action}. ${stdout || stderr || ""}`);
    await new Promise(resolve => setTimeout(resolve, 1000));
    const running = await getEngineRunning();
    res.json({ ok: true, action, streamRunning: running, message: action === "stop" ? "Broadcast engine stopped. The control panel remains online." : running ? "Broadcast engine is running." : "Command completed, but the broadcast engine is not running. Check the Logs panel." });
  } catch (e) {
    writeLog("ERROR", `Stream ${action} failed: ${e.message}`);
    res.status(500).json({ error: `Could not ${action} the broadcast engine: ${e.message}` });
  }
});
app.get("/api/env", (req, res) => {
  try {
    const d = getEnvDocument();
    res.set("Cache-Control", "no-store"); res.json({ content: d.content, path: ".env" });
  } catch (e) {
    writeLog("ERROR", `Could not read .env file: ${e.message}`);
    res.status(500).json({ error: `Could not read .env file: ${e.message}` });
  }
});
app.put("/api/env", (req, res) => {
  const content = req.body && req.body.content;
  if (typeof content !== "string" || !content.trim()) return res.status(400).json({ error: ".env file cannot be empty." });
  if (Buffer.byteLength(content, "utf8") > 64 * 1024) return res.status(413).json({ error: ".env file must be smaller than 64 KB." });
  const lines = content.split(/\r?\n/);
  const seen = new Set();
  for (const line of lines) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const idx = t.indexOf("=");
    if (idx < 1) return res.status(400).json({ error: `Invalid .env line: ${t.slice(0, 80)}` });
    const key = t.slice(0, idx).trim();
    if (!envAllowedKeys().has(key)) return res.status(400).json({ error: `Unsupported .env key "${key}". This editor only allows station connection and runtime settings.` });
    if (seen.has(key)) return res.status(400).json({ error: `Duplicate .env key "${key}".` });
    seen.add(key);
  }
  try {
    const file = envFilePath();
    const current = fs.readFileSync(file, "utf8");
    const backupDir = path.join(DATA_DIR, "config-backups");
    fs.mkdirSync(backupDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backup = path.join(backupDir, `env-${stamp}.bak`);
    fs.writeFileSync(backup, current, { mode: 0o600 });
    fs.writeFileSync(file, content.endsWith("\n") ? content : content + "\n", { mode: 0o600 });
    try { fs.chmodSync(file, 0o600); } catch {}
    writeLog("CONTROL", `Project .env saved; backup created at ${path.basename(backup)}. Secret values omitted from log.`);
    res.json({ ok: true, backup: path.basename(backup), message: "Project .env saved and backed up. Restart the Liquidsoap container from the project folder to apply changes." });
  } catch (e) {
    writeLog("ERROR", `Could not save .env file: ${e.message}`);
    res.status(500).json({ error: `Could not save .env file: ${e.message}` });
  }
});
app.get("/api/logs", (req, res) => res.json({ content: readTail(LOG_FILE, 500), path: LOG_FILE }));
app.post("/api/logs/clear", (req, res) => {
  try { fs.writeFileSync(LOG_FILE, ""); writeLog("CONTROL", "Operator cleared the visible log history."); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.listen(PORT,"0.0.0.0",() => { writeLog("INFO", `Radio Automation v3.3 listening on ${PORT}`); setInterval(collectEngineLogs, 5000); collectEngineLogs(); });
